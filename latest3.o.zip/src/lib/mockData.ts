// Mock data for the application

export interface Donation {
  id: string;
  type: "clothes" | "food" | "essentials";
  description: string;
  quantity: string;
  status: "pending" | "in-progress" | "delivered";
  date: string;
  volunteer?: string;
  ngo?: string;
  pickupLocation?: string;
  deliveryLocation?: string;
}

export interface Volunteer {
  id: string;
  name: string;
  rating: number;
  distance: string;
  completedDeliveries: number;
  available: boolean;
  phone?: string;
  location?: { lat: number; lng: number };
}

export interface DeliveryRequest {
  id: string;
  donorName: string;
  donationType: "clothes" | "food" | "essentials";
  quantity: string;
  pickupAddress: string;
  deliveryAddress: string;
  ngoName: string;
  urgency: "low" | "medium" | "high";
  distance: string;
  status: "pending" | "accepted" | "completed";
  date: string;
}

export interface NGO {
  id: string;
  name: string;
  location: string;
  contact: string;
  email: string;
  type: string;
  rating: number;
}

export interface Recognition {
  donorOfMonth: {
    name: string;
    contributions: string;
    badge: string;
  };
  volunteerOfMonth: {
    name: string;
    deliveries: number;
    badge: string;
  };
  ngoOfMonth: {
    name: string;
    impact: string;
    badge: string;
  };
}

// Mock Donations
export const mockDonations: Donation[] = [
  {
    id: "D001",
    type: "clothes",
    description: "Winter jackets, sweaters, and blankets",
    quantity: "15 items",
    status: "delivered",
    date: "2026-02-01",
    volunteer: "Sarah Johnson",
    ngo: "Hope Foundation",
    pickupLocation: "123 Main St",
    deliveryLocation: "456 Shelter Ave"
  },
  {
    id: "D002",
    type: "food",
    description: "Canned goods, rice, and pasta",
    quantity: "20 kg",
    status: "in-progress",
    date: "2026-02-05",
    volunteer: "Mike Chen",
    ngo: "Food Bank Central",
    pickupLocation: "789 Oak Rd",
    deliveryLocation: "321 Community St"
  },
  {
    id: "D003",
    type: "essentials",
    description: "School supplies and stationery",
    quantity: "30 sets",
    status: "pending",
    date: "2026-02-06",
    pickupLocation: "555 Elm St",
    deliveryLocation: "777 Education Blvd"
  }
];

// Mock Volunteers
export const mockVolunteers: Volunteer[] = [
  {
    id: "V001",
    name: "Sarah Johnson",
    rating: 4.8,
    distance: "2.3 km",
    completedDeliveries: 47,
    available: true,
    phone: "+1 234 567 8901",
    location: { lat: 40.7128, lng: -74.0060 }
  },
  {
    id: "V002",
    name: "Mike Chen",
    rating: 4.9,
    distance: "1.8 km",
    completedDeliveries: 62,
    available: true,
    phone: "+1 234 567 8902",
    location: { lat: 40.7580, lng: -73.9855 }
  },
  {
    id: "V003",
    name: "Emily Rodriguez",
    rating: 4.7,
    distance: "3.5 km",
    completedDeliveries: 35,
    available: false,
    phone: "+1 234 567 8903",
    location: { lat: 40.7489, lng: -73.9680 }
  },
  {
    id: "V004",
    name: "David Park",
    rating: 4.6,
    distance: "4.2 km",
    completedDeliveries: 28,
    available: true,
    phone: "+1 234 567 8904",
    location: { lat: 40.7614, lng: -73.9776 }
  }
];

// Mock Delivery Requests
export const mockDeliveryRequests: DeliveryRequest[] = [
  {
    id: "DR001",
    donorName: "John Smith",
    donationType: "clothes",
    quantity: "10 bags",
    pickupAddress: "123 Main St, Manhattan",
    deliveryAddress: "Hope Foundation, 456 Shelter Ave",
    ngoName: "Hope Foundation",
    urgency: "high",
    distance: "3.2 km",
    status: "pending",
    date: "2026-02-07"
  },
  {
    id: "DR002",
    donorName: "Maria Garcia",
    donationType: "food",
    quantity: "25 kg",
    pickupAddress: "789 Broadway, Queens",
    deliveryAddress: "Food Bank Central, 321 Community St",
    ngoName: "Food Bank Central",
    urgency: "medium",
    distance: "5.1 km",
    status: "pending",
    date: "2026-02-07"
  },
  {
    id: "DR003",
    donorName: "Tech Corp Inc.",
    donationType: "essentials",
    quantity: "50 units",
    pickupAddress: "555 Tech Plaza, Brooklyn",
    deliveryAddress: "Education First, 777 School Rd",
    ngoName: "Education First",
    urgency: "low",
    distance: "7.8 km",
    status: "accepted",
    date: "2026-02-06"
  }
];

// Mock NGOs
export const mockNGOs: NGO[] = [
  {
    id: "NGO001",
    name: "Hope Foundation",
    location: "456 Shelter Ave, Manhattan",
    contact: "+1 234 567 9001",
    email: "contact@hopefoundation.org",
    type: "Homeless Shelter",
    rating: 4.9
  },
  {
    id: "NGO002",
    name: "Food Bank Central",
    location: "321 Community St, Bronx",
    contact: "+1 234 567 9002",
    email: "info@foodbankcentral.org",
    type: "Food Distribution",
    rating: 4.8
  },
  {
    id: "NGO003",
    name: "Education First",
    location: "777 School Rd, Queens",
    contact: "+1 234 567 9003",
    email: "help@educationfirst.org",
    type: "Educational Support",
    rating: 4.7
  }
];

// Mock Recognition Data
export const mockRecognition: Recognition = {
  donorOfMonth: {
    name: "Tech Corp Inc.",
    contributions: "150 donations, 2,500+ items",
    badge: "🏆 Gold Donor"
  },
  volunteerOfMonth: {
    name: "Sarah Johnson",
    deliveries: 47,
    badge: "⭐ Star Volunteer"
  },
  ngoOfMonth: {
    name: "Hope Foundation",
    impact: "1,200+ lives touched",
    badge: "💚 Impact Champion"
  }
};
