import { createBrowserRouter } from "react-router";
import Landing from "./pages/Landing";
import Onboarding from "./pages/Onboarding";
import RoleSelection from "./pages/RoleSelection";
import DonorDashboard from "./pages/DonorDashboard";
import VolunteerDashboard from "./pages/VolunteerDashboard";
import NGODashboard from "./pages/NGODashboard";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Landing,
  },
  {
    path: "/onboarding",
    Component: Onboarding,
  },
  {
    path: "/role-selection",
    Component: RoleSelection,
  },
  {
    path: "/donor",
    Component: DonorDashboard,
  },
  {
    path: "/volunteer",
    Component: VolunteerDashboard,
  },
  {
    path: "/ngo",
    Component: NGODashboard,
  },
]);
