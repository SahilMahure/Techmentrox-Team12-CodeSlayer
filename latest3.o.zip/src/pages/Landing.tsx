import { motion } from "motion/react";
import { Button } from "../components/ui/button";
import { Heart, Users, Building2, ArrowRight, Sparkles } from "lucide-react";
import { useNavigate } from "react-router";
import logo from "figma:asset/c0160807a5cb025e77d8935afa6685098e9c8896.png";
import { CanvasRevealEffect } from "../components/CanvasRevealEffect";

export default function Landing() {
  const navigate = useNavigate();

  return (
    <div className="relative min-h-screen bg-black overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 z-0">
        <CanvasRevealEffect
          animationSpeed={3}
          containerClassName="bg-black"
          colors={[
            [255, 166, 0],
            [255, 200, 100],
          ]}
          dotSize={4}
        />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(0,0,0,0.3)_0%,_rgba(0,0,0,0.9)_100%)]" />
        <div className="absolute top-0 left-0 right-0 h-1/3 bg-gradient-to-b from-black via-black/50 to-transparent" />
      </div>

      {/* Content Layer */}
      <div className="relative z-10">
        {/* Minimal Floating Navigation */}
        <nav className="fixed top-6 left-1/2 transform -translate-x-1/2 z-50">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-6 px-6 py-3 backdrop-blur-md bg-white/5 border border-white/10 rounded-full"
          >
            <div className="flex items-center gap-2">
              <img src={logo} alt="Link4Good" className="size-8" />
              <span className="text-white font-semibold">Link4Good</span>
            </div>
            <div className="h-4 w-px bg-white/20"></div>
            <Button
              onClick={() => navigate('/onboarding')}
              className="bg-white/10 hover:bg-white/20 text-white border border-white/20 rounded-full px-6"
              size="sm"
            >
              Get Started
            </Button>
          </motion.div>
        </nav>

        {/* Hero Section */}
        <section className="min-h-screen flex flex-col items-center justify-center px-4 sm:px-6 lg:px-8">
          <div className="max-w-5xl mx-auto text-center space-y-8">
            {/* Main Headline */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="space-y-6"
            >
              <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-white leading-tight">
                Every donation finds
                <br />
                <span className="bg-gradient-to-r from-amber-400 via-orange-500 to-amber-600 bg-clip-text text-transparent">
                  its purpose
                </span>
              </h1>
              <p className="text-xl sm:text-2xl text-white/60 max-w-3xl mx-auto">
                Connect donors, volunteers, and NGOs on one platform.
                <br />
                Track your impact in real-time.
              </p>
            </motion.div>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="flex flex-col sm:flex-row gap-4 justify-center items-center"
            >
              <Button
                size="lg"
                onClick={() => navigate('/onboarding')}
                className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white border-0 rounded-full px-8 py-6 text-lg font-semibold group relative overflow-hidden"
              >
                <span className="relative z-10 flex items-center gap-2">
                  Start Your Journey
                  <ArrowRight className="size-5 group-hover:translate-x-1 transition-transform" />
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-amber-600 to-orange-700 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-white/5 hover:bg-white/10 text-white border border-white/20 rounded-full px-8 py-6 text-lg backdrop-blur-sm"
              >
                Learn More
              </Button>
            </motion.div>

            {/* Stats */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.6 }}
              className="grid grid-cols-3 gap-8 pt-16 max-w-2xl mx-auto"
            >
              {[
                { value: "5000+", label: "Donations", color: "from-amber-400 to-orange-500" },
                { value: "3000+", label: "Volunteers", color: "from-blue-400 to-cyan-500" },
                { value: "200+", label: "NGOs", color: "from-emerald-400 to-teal-500" }
              ].map((stat, index) => (
                <div key={index} className="text-center">
                  <div className={`text-3xl sm:text-4xl font-bold bg-gradient-to-r ${stat.color} bg-clip-text text-transparent mb-2`}>
                    {stat.value}
                  </div>
                  <div className="text-sm text-white/50">{stat.label}</div>
                </div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="py-32 px-4 sm:px-6 lg:px-8 relative">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/50 to-black"></div>
          <div className="max-w-7xl mx-auto relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-20"
            >
              <h2 className="text-4xl sm:text-5xl font-bold text-white mb-6">
                Three Roles, One Mission
              </h2>
              <p className="text-xl text-white/60 max-w-2xl mx-auto">
                A seamless platform designed for changemakers
              </p>
            </motion.div>

            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  icon: Heart,
                  title: "Donors",
                  description: "Donate clothes, food, or essentials. Track your donations in real-time and see the impact you create.",
                  gradient: "from-amber-500/20 to-orange-500/20",
                  border: "border-amber-500/30",
                  iconColor: "text-amber-500"
                },
                {
                  icon: Users,
                  title: "Volunteers",
                  description: "Accept requests, coordinate pickups, and deliver hope. Build your impact profile with every delivery.",
                  gradient: "from-blue-500/20 to-cyan-500/20",
                  border: "border-blue-500/30",
                  iconColor: "text-blue-500"
                },
                {
                  icon: Building2,
                  title: "NGOs",
                  description: "Receive donations efficiently, track deliveries, and focus on what matters - helping those in need.",
                  gradient: "from-emerald-500/20 to-teal-500/20",
                  border: "border-emerald-500/30",
                  iconColor: "text-emerald-500"
                }
              ].map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="group relative"
                >
                  <div className={`h-full p-8 rounded-2xl bg-gradient-to-br ${feature.gradient} backdrop-blur-sm border ${feature.border} hover:border-opacity-60 transition-all duration-300`}>
                    <div className={`inline-flex p-4 rounded-xl bg-black/40 mb-6 group-hover:scale-110 transition-transform ${feature.iconColor}`}>
                      <feature.icon className="size-8" strokeWidth={1.5} />
                    </div>
                    <h3 className="text-2xl font-semibold text-white mb-4">{feature.title}</h3>
                    <p className="text-white/60 leading-relaxed">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-32 px-4 sm:px-6 lg:px-8 relative">
          <div className="absolute inset-0 bg-gradient-to-b from-black via-amber-950/20 to-black"></div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-4xl mx-auto text-center relative z-10"
          >
            <h2 className="text-4xl sm:text-5xl font-bold text-white mb-6">
              Ready to Make an Impact?
            </h2>
            <p className="text-xl text-white/60 mb-10">
              Join thousands of donors, volunteers, and NGOs creating positive change every day.
            </p>
            <Button
              size="lg"
              onClick={() => navigate('/onboarding')}
              className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white border-0 rounded-full px-10 py-7 text-lg font-semibold"
            >
              Join Link4Good Today
            </Button>
          </motion.div>
        </section>

        {/* Footer */}
        <footer className="py-12 px-4 sm:px-6 lg:px-8 border-t border-white/10">
          <div className="max-w-7xl mx-auto text-center">
            <div className="flex items-center justify-center gap-3 mb-4">
              <img src={logo} alt="Link4Good" className="size-8" />
              <span className="text-lg font-semibold text-white">Link4Good</span>
            </div>
            <p className="text-white/40 text-sm">
              Building a world where every contribution counts. © 2026 Link4Good. All rights reserved.
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}