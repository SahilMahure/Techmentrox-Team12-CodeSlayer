import { useState } from "react";
import { DashboardLayout } from "../components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "../components/ui/dialog";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { RadioGroup, RadioGroupItem } from "../components/ui/radio-group";
import { OpenStreetMap } from "../components/OpenStreetMap";
import { mockDonations, mockVolunteers, mockRecognition, type Donation, type Volunteer } from "../lib/mockData";
import { Package, Clock, CheckCircle, Plus, MapPin, Star, Phone, Award, TrendingUp } from "lucide-react";
import { motion } from "motion/react";
import { toast } from "sonner@2.0.3";

export default function DonorDashboard() {
  const [donations, setDonations] = useState<Donation[]>(mockDonations);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [newDonation, setNewDonation] = useState({
    type: "clothes" as "clothes" | "food" | "essentials",
    description: "",
    quantity: "",
    urgency: "medium" as "low" | "medium" | "high",
    pickupPreference: "pickup" as "pickup" | "dropoff"
  });

  // Get user profile from localStorage
  const userProfile = JSON.parse(localStorage.getItem('userProfile') || '{}');
  const userName = userProfile.name || userProfile.organizationName || 'Donor';

  const handleCreateDonation = () => {
    const donation: Donation = {
      id: `D${String(donations.length + 1).padStart(3, '0')}`,
      type: newDonation.type,
      description: newDonation.description,
      quantity: newDonation.quantity,
      status: "pending",
      date: new Date().toISOString().split('T')[0],
      pickupLocation: "Your Location"
    };
    
    setDonations([donation, ...donations]);
    setIsCreateDialogOpen(false);
    toast.success("Donation created successfully!", {
      description: "A volunteer will be assigned shortly."
    });
    
    // Reset form
    setNewDonation({
      type: "clothes",
      description: "",
      quantity: "",
      urgency: "medium",
      pickupPreference: "pickup"
    });
  };

  const getStatusColor = (status: Donation['status']) => {
    switch (status) {
      case "delivered": return "bg-emerald-100 text-emerald-800 border-emerald-200";
      case "in-progress": return "bg-blue-100 text-blue-800 border-blue-200";
      case "pending": return "bg-amber-100 text-amber-800 border-amber-200";
    }
  };

  const getStatusIcon = (status: Donation['status']) => {
    switch (status) {
      case "delivered": return <CheckCircle className="size-4" />;
      case "in-progress": return <Clock className="size-4" />;
      case "pending": return <Package className="size-4" />;
    }
  };

  const getTypeEmoji = (type: Donation['type']) => {
    switch (type) {
      case "clothes": return "👕";
      case "food": return "🍲";
      case "essentials": return "📦";
    }
  };

  // Map data for active donations
  const mapLocations = donations
    .filter(d => d.status === "in-progress")
    .flatMap(d => [
      { lat: 40.7128, lng: -74.0060, label: d.pickupLocation || "Pickup", type: "pickup" as const },
      { lat: 40.7580, lng: -73.9855, label: "Volunteer", type: "volunteer" as const },
      { lat: 40.7489, lng: -73.9680, label: d.deliveryLocation || "Delivery", type: "delivery" as const }
    ]);

  const stats = {
    total: donations.length,
    delivered: donations.filter(d => d.status === "delivered").length,
    inProgress: donations.filter(d => d.status === "in-progress").length,
    pending: donations.filter(d => d.status === "pending").length
  };

  return (
    <DashboardLayout role="donor">
      <div className="space-y-8">
        {/* Welcome Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-amber-500 to-orange-600 rounded-2xl p-8 text-white shadow-xl"
        >
          <h1 className="text-3xl mb-2">Welcome back, {userName}! 🎁</h1>
          <p className="text-amber-50 text-lg">
            Thank you for making a difference. Your generosity changes lives.
          </p>
        </motion.div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[
            { label: "Total Donations", value: stats.total, icon: Package, color: "text-purple-600 bg-purple-100" },
            { label: "Delivered", value: stats.delivered, icon: CheckCircle, color: "text-emerald-600 bg-emerald-100" },
            { label: "In Progress", value: stats.inProgress, icon: Clock, color: "text-blue-600 bg-blue-100" },
            { label: "Pending", value: stats.pending, icon: TrendingUp, color: "text-amber-600 bg-amber-100" }
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">{stat.label}</p>
                      <p className="text-3xl font-semibold mt-1">{stat.value}</p>
                    </div>
                    <div className={`p-3 rounded-xl ${stat.color}`}>
                      <stat.icon className="size-6" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content - Left Side */}
          <div className="lg:col-span-2 space-y-6">
            {/* Donations Management */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                <div>
                  <CardTitle>Your Donations</CardTitle>
                  <CardDescription>Track and manage all your donations</CardDescription>
                </div>
                <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-amber-600 hover:bg-amber-700">
                      <Plus className="size-4 mr-2" />
                      New Donation
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>Create New Donation</DialogTitle>
                      <DialogDescription>
                        Fill in the details of what you'd like to donate
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label>Donation Type</Label>
                        <Select
                          value={newDonation.type}
                          onValueChange={(value: any) => setNewDonation({ ...newDonation, type: value })}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="clothes">👕 Clothes</SelectItem>
                            <SelectItem value="food">🍲 Food</SelectItem>
                            <SelectItem value="essentials">📦 Essential Items</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label>Description</Label>
                        <Textarea
                          placeholder="Describe what you're donating..."
                          value={newDonation.description}
                          onChange={(e) => setNewDonation({ ...newDonation, description: e.target.value })}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>Quantity</Label>
                        <Input
                          placeholder="e.g., 10 bags, 15 kg, 20 items"
                          value={newDonation.quantity}
                          onChange={(e) => setNewDonation({ ...newDonation, quantity: e.target.value })}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>Urgency Level</Label>
                        <RadioGroup
                          value={newDonation.urgency}
                          onValueChange={(value: any) => setNewDonation({ ...newDonation, urgency: value })}
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="low" id="low" />
                            <Label htmlFor="low" className="font-normal">Low - Can wait a few days</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="medium" id="medium" />
                            <Label htmlFor="medium" className="font-normal">Medium - Within this week</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="high" id="high" />
                            <Label htmlFor="high" className="font-normal">High - As soon as possible</Label>
                          </div>
                        </RadioGroup>
                      </div>

                      <div className="space-y-2">
                        <Label>Pickup Preference</Label>
                        <RadioGroup
                          value={newDonation.pickupPreference}
                          onValueChange={(value: any) => setNewDonation({ ...newDonation, pickupPreference: value })}
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="pickup" id="pickup" />
                            <Label htmlFor="pickup" className="font-normal">Volunteer pickup from my location</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="dropoff" id="dropoff" />
                            <Label htmlFor="dropoff" className="font-normal">I'll drop off at NGO</Label>
                          </div>
                        </RadioGroup>
                      </div>
                    </div>
                    <div className="flex justify-end gap-3">
                      <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button 
                        className="bg-amber-600 hover:bg-amber-700"
                        onClick={handleCreateDonation}
                        disabled={!newDonation.description || !newDonation.quantity}
                      >
                        Create Donation
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="all" className="space-y-4">
                  <TabsList>
                    <TabsTrigger value="all">All ({donations.length})</TabsTrigger>
                    <TabsTrigger value="pending">Pending ({stats.pending})</TabsTrigger>
                    <TabsTrigger value="in-progress">In Progress ({stats.inProgress})</TabsTrigger>
                    <TabsTrigger value="delivered">Delivered ({stats.delivered})</TabsTrigger>
                  </TabsList>

                  {['all', 'pending', 'in-progress', 'delivered'].map(status => (
                    <TabsContent key={status} value={status} className="space-y-3">
                      {donations
                        .filter(d => status === 'all' || d.status === status)
                        .map((donation, index) => (
                          <motion.div
                            key={donation.id}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.05 }}
                          >
                            <Card className="hover:shadow-md transition-shadow">
                              <CardContent className="pt-6">
                                <div className="flex items-start justify-between">
                                  <div className="flex gap-4 flex-1">
                                    <div className="text-3xl">{getTypeEmoji(donation.type)}</div>
                                    <div className="flex-1">
                                      <div className="flex items-center gap-2 mb-2">
                                        <h4 className="font-semibold">{donation.description}</h4>
                                        <Badge className={getStatusColor(donation.status)}>
                                          {getStatusIcon(donation.status)}
                                          <span className="ml-1 capitalize">{donation.status}</span>
                                        </Badge>
                                      </div>
                                      <div className="space-y-1 text-sm text-muted-foreground">
                                        <p>📦 Quantity: {donation.quantity}</p>
                                        <p>📅 Date: {new Date(donation.date).toLocaleDateString()}</p>
                                        {donation.volunteer && (
                                          <p>👤 Volunteer: {donation.volunteer}</p>
                                        )}
                                        {donation.ngo && (
                                          <p>🏛️ NGO: {donation.ngo}</p>
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                  {donation.status === "in-progress" && (
                                    <Button size="sm" variant="outline">
                                      <MapPin className="size-4 mr-2" />
                                      Track
                                    </Button>
                                  )}
                                </div>
                              </CardContent>
                            </Card>
                          </motion.div>
                        ))}
                      {donations.filter(d => status === 'all' || d.status === status).length === 0 && (
                        <div className="text-center py-12 text-muted-foreground">
                          <Package className="size-12 mx-auto mb-4 opacity-30" />
                          <p>No donations in this category yet</p>
                        </div>
                      )}
                    </TabsContent>
                  ))}
                </Tabs>
              </CardContent>
            </Card>

            {/* Map View */}
            {mapLocations.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Live Tracking</CardTitle>
                  <CardDescription>Real-time location of active deliveries</CardDescription>
                </CardHeader>
                <CardContent>
                  <OpenStreetMap locations={mapLocations} />
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">
            {/* Available Volunteers */}
            <Card>
              <CardHeader>
                <CardTitle>Available Volunteers</CardTitle>
                <CardDescription>Nearby volunteers ready to help</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {mockVolunteers.filter(v => v.available).map((volunteer) => (
                  <Card key={volunteer.id} className="border border-border hover:border-blue-300 transition-colors">
                    <CardContent className="pt-4">
                      <div className="space-y-3">
                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="font-medium">{volunteer.name}</h4>
                            <div className="flex items-center gap-1 mt-1">
                              <Star className="size-3 fill-amber-500 text-amber-500" />
                              <span className="text-sm text-muted-foreground">{volunteer.rating}</span>
                            </div>
                          </div>
                          <Badge variant="secondary" className="text-xs">
                            {volunteer.distance}
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          ✅ {volunteer.completedDeliveries} deliveries completed
                        </div>
                        <Button size="sm" variant="outline" className="w-full">
                          <Phone className="size-3 mr-2" />
                          Contact
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Appreciation Section */}
        <div id="appreciation-section">
          <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-2 border-purple-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="size-6 text-purple-600" />
                This Month's Champions
              </CardTitle>
              <CardDescription>Celebrating our community heroes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                {/* Donor of the Month */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                >
                  <Card className="bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200">
                    <CardContent className="pt-6 text-center">
                      <div className="text-4xl mb-3">🏆</div>
                      <h3 className="font-semibold mb-1">Donor of the Month</h3>
                      <p className="text-lg font-medium text-amber-700 mb-2">{mockRecognition.donorOfMonth.name}</p>
                      <Badge className="bg-amber-100 text-amber-800 border-amber-200 mb-3">
                        {mockRecognition.donorOfMonth.badge}
                      </Badge>
                      <p className="text-sm text-muted-foreground">{mockRecognition.donorOfMonth.contributions}</p>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Volunteer of the Month */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200">
                    <CardContent className="pt-6 text-center">
                      <div className="text-4xl mb-3">⭐</div>
                      <h3 className="font-semibold mb-1">Volunteer of the Month</h3>
                      <p className="text-lg font-medium text-blue-700 mb-2">{mockRecognition.volunteerOfMonth.name}</p>
                      <Badge className="bg-blue-100 text-blue-800 border-blue-200 mb-3">
                        {mockRecognition.volunteerOfMonth.badge}
                      </Badge>
                      <p className="text-sm text-muted-foreground">{mockRecognition.volunteerOfMonth.deliveries} deliveries completed</p>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* NGO of the Month */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  <Card className="bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-200">
                    <CardContent className="pt-6 text-center">
                      <div className="text-4xl mb-3">💚</div>
                      <h3 className="font-semibold mb-1">NGO of the Month</h3>
                      <p className="text-lg font-medium text-emerald-700 mb-2">{mockRecognition.ngoOfMonth.name}</p>
                      <Badge className="bg-emerald-100 text-emerald-800 border-emerald-200 mb-3">
                        {mockRecognition.ngoOfMonth.badge}
                      </Badge>
                      <p className="text-sm text-muted-foreground">{mockRecognition.ngoOfMonth.impact}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}