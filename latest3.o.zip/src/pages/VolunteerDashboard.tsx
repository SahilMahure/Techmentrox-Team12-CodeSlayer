import { useState } from "react";
import { DashboardLayout } from "../components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { OpenStreetMap } from "../components/OpenStreetMap";
import { mockDeliveryRequests, mockNGOs, mockRecognition, type DeliveryRequest } from "../lib/mockData";
import { Package, CheckCircle, Clock, MapPin, Phone, Mail, Star, Award, TrendingUp, Navigation } from "lucide-react";
import { motion } from "motion/react";
import { toast } from "sonner@2.0.3";

export default function VolunteerDashboard() {
  const [requests, setRequests] = useState<DeliveryRequest[]>(mockDeliveryRequests);

  // Get user profile from localStorage
  const userProfile = JSON.parse(localStorage.getItem('userProfile') || '{}');
  const userName = userProfile.name || 'Volunteer';

  const handleAcceptRequest = (requestId: string) => {
    setRequests(prev => prev.map(req => 
      req.id === requestId ? { ...req, status: "accepted" } : req
    ));
    toast.success("Request accepted!", {
      description: "Check your pending deliveries for details."
    });
  };

  const handleCompleteDelivery = (requestId: string) => {
    setRequests(prev => prev.map(req => 
      req.id === requestId ? { ...req, status: "completed" } : req
    ));
    toast.success("Delivery completed! 🎉", {
      description: "Thank you for making a difference!"
    });
  };

  const getUrgencyColor = (urgency: DeliveryRequest['urgency']) => {
    switch (urgency) {
      case "high": return "bg-red-100 text-red-800 border-red-200";
      case "medium": return "bg-amber-100 text-amber-800 border-amber-200";
      case "low": return "bg-green-100 text-green-800 border-green-200";
    }
  };

  const getTypeEmoji = (type: DeliveryRequest['donationType']) => {
    switch (type) {
      case "clothes": return "👕";
      case "food": return "🍲";
      case "essentials": return "📦";
    }
  };

  const stats = {
    completed: requests.filter(r => r.status === "completed").length,
    pending: requests.filter(r => r.status === "accepted").length,
    available: requests.filter(r => r.status === "pending").length,
  };

  // Map data for active deliveries
  const mapLocations = requests
    .filter(r => r.status === "accepted")
    .flatMap(r => [
      { lat: 40.7128, lng: -74.0060, label: "Pickup Location", type: "pickup" as const },
      { lat: 40.7580, lng: -73.9855, label: "You (Volunteer)", type: "volunteer" as const },
      { lat: 40.7489, lng: -73.9680, label: r.ngoName, type: "ngo" as const }
    ]);

  return (
    <DashboardLayout role="volunteer">
      <div className="space-y-8">
        {/* Welcome Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-blue-500 to-cyan-600 rounded-2xl p-8 text-white shadow-xl"
        >
          <h1 className="text-3xl mb-2">Welcome back, {userName}! 💙</h1>
          <p className="text-blue-50 text-lg">
            Your dedication and time create ripples of change in our community.
          </p>
        </motion.div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { label: "Completed Deliveries", value: stats.completed + 47, icon: CheckCircle, color: "text-emerald-600 bg-emerald-100" },
            { label: "Pending Deliveries", value: stats.pending, icon: Clock, color: "text-blue-600 bg-blue-100" },
            { label: "Available Requests", value: stats.available, icon: TrendingUp, color: "text-purple-600 bg-purple-100" }
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">{stat.label}</p>
                      <p className="text-3xl font-semibold mt-1">{stat.value}</p>
                    </div>
                    <div className={`p-3 rounded-xl ${stat.color}`}>
                      <stat.icon className="size-6" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content - Left Side */}
          <div className="lg:col-span-2 space-y-6">
            {/* Delivery Requests Management */}
            <Card>
              <CardHeader>
                <CardTitle>Delivery Management</CardTitle>
                <CardDescription>Accept requests and manage your deliveries</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="available" className="space-y-4">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="available">
                      Available ({stats.available})
                    </TabsTrigger>
                    <TabsTrigger value="pending">
                      Pending ({stats.pending})
                    </TabsTrigger>
                    <TabsTrigger value="history">
                      History ({stats.completed})
                    </TabsTrigger>
                  </TabsList>

                  {/* Available Requests */}
                  <TabsContent value="available" className="space-y-3">
                    {requests
                      .filter(r => r.status === "pending")
                      .map((request, index) => (
                        <motion.div
                          key={request.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.05 }}
                        >
                          <Card className="hover:shadow-md transition-shadow border-2 hover:border-blue-300">
                            <CardContent className="pt-6">
                              <div className="space-y-4">
                                <div className="flex items-start justify-between">
                                  <div className="flex gap-3">
                                    <div className="text-3xl">{getTypeEmoji(request.donationType)}</div>
                                    <div>
                                      <div className="flex items-center gap-2 mb-2">
                                        <h4 className="font-semibold">Pickup from {request.donorName}</h4>
                                        <Badge className={getUrgencyColor(request.urgency)}>
                                          {request.urgency} priority
                                        </Badge>
                                      </div>
                                      <div className="space-y-1 text-sm text-muted-foreground">
                                        <p>📦 {request.quantity} of {request.donationType}</p>
                                        <p>📍 {request.distance} away</p>
                                        <p>🏛️ Deliver to: {request.ngoName}</p>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                
                                <div className="bg-muted/50 rounded-lg p-3 space-y-2 text-sm">
                                  <div className="flex items-start gap-2">
                                    <MapPin className="size-4 text-blue-600 mt-0.5 flex-shrink-0" />
                                    <div>
                                      <p className="font-medium">Pickup</p>
                                      <p className="text-muted-foreground">{request.pickupAddress}</p>
                                    </div>
                                  </div>
                                  <div className="flex items-start gap-2">
                                    <Navigation className="size-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                                    <div>
                                      <p className="font-medium">Delivery</p>
                                      <p className="text-muted-foreground">{request.deliveryAddress}</p>
                                    </div>
                                  </div>
                                </div>

                                <Button 
                                  className="w-full bg-blue-600 hover:bg-blue-700"
                                  onClick={() => handleAcceptRequest(request.id)}
                                >
                                  Accept Request
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                    {requests.filter(r => r.status === "pending").length === 0 && (
                      <div className="text-center py-12 text-muted-foreground">
                        <Package className="size-12 mx-auto mb-4 opacity-30" />
                        <p>No available requests at the moment</p>
                        <p className="text-sm mt-2">Check back soon for new opportunities!</p>
                      </div>
                    )}
                  </TabsContent>

                  {/* Pending Deliveries */}
                  <TabsContent value="pending" className="space-y-3">
                    {requests
                      .filter(r => r.status === "accepted")
                      .map((request, index) => (
                        <motion.div
                          key={request.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.05 }}
                        >
                          <Card className="hover:shadow-md transition-shadow border-2 border-blue-200 bg-blue-50/50">
                            <CardContent className="pt-6">
                              <div className="space-y-4">
                                <div className="flex items-start justify-between">
                                  <div className="flex gap-3">
                                    <div className="text-3xl">{getTypeEmoji(request.donationType)}</div>
                                    <div>
                                      <h4 className="font-semibold mb-2">Active Delivery - {request.donorName}</h4>
                                      <div className="space-y-1 text-sm text-muted-foreground">
                                        <p>📦 {request.quantity} of {request.donationType}</p>
                                        <p>🏛️ Destination: {request.ngoName}</p>
                                        <p>📅 Accepted: {new Date(request.date).toLocaleDateString()}</p>
                                      </div>
                                    </div>
                                  </div>
                                </div>

                                <div className="flex gap-2">
                                  <Button variant="outline" className="flex-1">
                                    <MapPin className="size-4 mr-2" />
                                    View Route
                                  </Button>
                                  <Button 
                                    className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                                    onClick={() => handleCompleteDelivery(request.id)}
                                  >
                                    <CheckCircle className="size-4 mr-2" />
                                    Mark Complete
                                  </Button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                    {requests.filter(r => r.status === "accepted").length === 0 && (
                      <div className="text-center py-12 text-muted-foreground">
                        <Clock className="size-12 mx-auto mb-4 opacity-30" />
                        <p>No pending deliveries</p>
                        <p className="text-sm mt-2">Accept requests to start making an impact!</p>
                      </div>
                    )}
                  </TabsContent>

                  {/* Delivery History */}
                  <TabsContent value="history" className="space-y-3">
                    {requests
                      .filter(r => r.status === "completed")
                      .map((request, index) => (
                        <motion.div
                          key={request.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.05 }}
                        >
                          <Card className="hover:shadow-md transition-shadow">
                            <CardContent className="pt-6">
                              <div className="flex items-start gap-3">
                                <CheckCircle className="size-5 text-emerald-600 mt-1" />
                                <div className="flex-1">
                                  <h4 className="font-medium mb-1">{request.donorName} → {request.ngoName}</h4>
                                  <p className="text-sm text-muted-foreground">
                                    {request.quantity} delivered • {new Date(request.date).toLocaleDateString()}
                                  </p>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                    <div className="text-center py-8 text-muted-foreground border-t">
                      <p className="text-sm">Showing recent completions</p>
                      <p className="text-xs mt-1">Total lifetime deliveries: 47</p>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            {/* Map View */}
            {mapLocations.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Active Route Tracking</CardTitle>
                  <CardDescription>Your current delivery routes</CardDescription>
                </CardHeader>
                <CardContent>
                  <OpenStreetMap locations={mapLocations} />
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">
            {/* NGO Contacts */}
            <Card>
              <CardHeader>
                <CardTitle>NGO Partners</CardTitle>
                <CardDescription>Organizations you deliver to</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {mockNGOs.map((ngo) => (
                  <Card key={ngo.id} className="border border-border hover:border-emerald-300 transition-colors">
                    <CardContent className="pt-4">
                      <div className="space-y-3">
                        <div>
                          <h4 className="font-medium mb-1">{ngo.name}</h4>
                          <div className="flex items-center gap-1 mb-2">
                            <Star className="size-3 fill-amber-500 text-amber-500" />
                            <span className="text-sm text-muted-foreground">{ngo.rating}</span>
                          </div>
                          <Badge variant="secondary" className="text-xs mb-2">
                            {ngo.type}
                          </Badge>
                        </div>
                        
                        <div className="space-y-2 text-sm text-muted-foreground">
                          <div className="flex items-center gap-2">
                            <MapPin className="size-3" />
                            <span className="text-xs">{ngo.location}</span>
                          </div>
                        </div>

                        <div className="flex gap-2">
                          <Button size="sm" variant="outline" className="flex-1">
                            <Phone className="size-3 mr-1" />
                            Call
                          </Button>
                          <Button size="sm" variant="outline" className="flex-1">
                            <Mail className="size-3 mr-1" />
                            Email
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </CardContent>
            </Card>

            {/* Performance Badge */}
            <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-2 border-blue-200">
              <CardContent className="pt-6 text-center">
                <div className="text-5xl mb-3">⭐</div>
                <h3 className="font-semibold mb-2">Your Rating</h3>
                <div className="text-3xl font-bold text-blue-700 mb-2">4.8</div>
                <div className="flex justify-center gap-1 mb-3">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className={`size-4 ${star <= 4 ? 'fill-amber-500 text-amber-500' : 'text-gray-300'}`} />
                  ))}
                </div>
                <p className="text-sm text-muted-foreground">Based on 47 deliveries</p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Appreciation Section */}
        <div id="appreciation-section">
          <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-2 border-purple-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="size-6 text-purple-600" />
                This Month's Champions
              </CardTitle>
              <CardDescription>Celebrating our community heroes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                {/* Donor of the Month */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                >
                  <Card className="bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200">
                    <CardContent className="pt-6 text-center">
                      <div className="text-4xl mb-3">🏆</div>
                      <h3 className="font-semibold mb-1">Donor of the Month</h3>
                      <p className="text-lg font-medium text-amber-700 mb-2">{mockRecognition.donorOfMonth.name}</p>
                      <Badge className="bg-amber-100 text-amber-800 border-amber-200 mb-3">
                        {mockRecognition.donorOfMonth.badge}
                      </Badge>
                      <p className="text-sm text-muted-foreground">{mockRecognition.donorOfMonth.contributions}</p>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Volunteer of the Month */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200">
                    <CardContent className="pt-6 text-center">
                      <div className="text-4xl mb-3">⭐</div>
                      <h3 className="font-semibold mb-1">Volunteer of the Month</h3>
                      <p className="text-lg font-medium text-blue-700 mb-2">{mockRecognition.volunteerOfMonth.name}</p>
                      <Badge className="bg-blue-100 text-blue-800 border-blue-200 mb-3">
                        {mockRecognition.volunteerOfMonth.badge}
                      </Badge>
                      <p className="text-sm text-muted-foreground">{mockRecognition.volunteerOfMonth.deliveries} deliveries completed</p>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* NGO of the Month */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  <Card className="bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-200">
                    <CardContent className="pt-6 text-center">
                      <div className="text-4xl mb-3">💚</div>
                      <h3 className="font-semibold mb-1">NGO of the Month</h3>
                      <p className="text-lg font-medium text-emerald-700 mb-2">{mockRecognition.ngoOfMonth.name}</p>
                      <Badge className="bg-emerald-100 text-emerald-800 border-emerald-200 mb-3">
                        {mockRecognition.ngoOfMonth.badge}
                      </Badge>
                      <p className="text-sm text-muted-foreground">{mockRecognition.ngoOfMonth.impact}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}