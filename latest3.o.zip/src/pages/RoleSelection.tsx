import { motion } from "motion/react";
import { useNavigate } from "react-router";
import { Heart, Users, Building2, ArrowRight } from "lucide-react";
import { Button } from "../components/ui/button";
import logo from "figma:asset/c0160807a5cb025e77d8935afa6685098e9c8896.png";
import { CanvasRevealEffect } from "../components/CanvasRevealEffect";

export default function RoleSelection() {
  const navigate = useNavigate();

  const roles = [
    {
      id: "donor",
      title: "Donor Dashboard",
      description: "Manage your donations, track delivery status, and connect with volunteers",
      icon: Heart,
      gradient: "from-amber-500 to-orange-600",
      bgGradient: "from-amber-500/20 to-orange-500/20",
      borderColor: "border-amber-500/30",
      path: "/donor"
    },
    {
      id: "volunteer",
      title: "Volunteer Dashboard",
      description: "Accept delivery requests, coordinate with donors and NGOs, build your impact",
      icon: Users,
      gradient: "from-blue-500 to-cyan-600",
      bgGradient: "from-blue-500/20 to-cyan-500/20",
      borderColor: "border-blue-500/30",
      path: "/volunteer"
    },
    {
      id: "ngo",
      title: "NGO Dashboard",
      description: "Receive donations, manage deliveries, and serve your community efficiently",
      icon: Building2,
      gradient: "from-emerald-500 to-teal-600",
      bgGradient: "from-emerald-500/20 to-teal-500/20",
      borderColor: "border-emerald-500/30",
      path: "/ngo"
    },
  ];

  return (
    <div className="relative min-h-screen bg-black overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 z-0">
        <CanvasRevealEffect
          animationSpeed={3}
          containerClassName="bg-black"
          colors={[
            [255, 166, 0],
            [255, 200, 100],
          ]}
          dotSize={4}
        />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(0,0,0,0.3)_0%,_rgba(0,0,0,0.9)_100%)]" />
      </div>

      {/* Content */}
      <div className="relative z-10">
        {/* Floating Header */}
        <nav className="fixed top-6 left-1/2 transform -translate-x-1/2 z-50">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-2 px-6 py-3 backdrop-blur-md bg-white/5 border border-white/10 rounded-full"
          >
            <img src={logo} alt="Link4Good" className="size-8" />
            <span className="text-white font-semibold">Link4Good</span>
          </motion.div>
        </nav>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <h1 className="text-4xl sm:text-5xl text-white mb-4">Choose Your Role</h1>
            <p className="text-lg text-white/60 max-w-2xl mx-auto">
              Select how you'd like to make an impact today. You can always switch between roles later.
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {roles.map((role, index) => (
              <motion.div
                key={role.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02 }}
                className="group cursor-pointer"
                onClick={() => navigate(role.path)}
              >
                <div className={`h-full backdrop-blur-md bg-gradient-to-br ${role.bgGradient} rounded-2xl border-2 ${role.borderColor} hover:border-opacity-60 transition-all duration-300 overflow-hidden`}>
                  {/* Gradient Header */}
                  <div className={`h-40 bg-gradient-to-br ${role.gradient} relative overflow-hidden`}>
                    <div className="absolute inset-0 bg-black/20"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <motion.div
                        whileHover={{ scale: 1.1, rotate: 5 }}
                        transition={{ type: "spring", stiffness: 300 }}
                      >
                        <role.icon className="size-16 text-white" strokeWidth={1.5} />
                      </motion.div>
                    </div>
                    {/* Decorative circles */}
                    <div className="absolute -top-12 -right-12 size-32 bg-white/10 rounded-full"></div>
                    <div className="absolute -bottom-8 -left-8 size-24 bg-white/10 rounded-full"></div>
                  </div>

                  {/* Content */}
                  <div className="p-8">
                    <h2 className="text-2xl text-white mb-3">{role.title}</h2>
                    <p className="text-white/60 mb-6">
                      {role.description}
                    </p>

                    <Button 
                      className={`w-full bg-gradient-to-r ${role.gradient} text-white hover:opacity-90 group-hover:gap-3 transition-all border-0 rounded-full`}
                    >
                      Enter Dashboard
                      <ArrowRight className="size-4 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </div>

                  {/* Hover Effect */}
                  <div className={`h-1 bg-gradient-to-r ${role.gradient} opacity-0 group-hover:opacity-100 transition-opacity`}></div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Info Banner */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="mt-16 max-w-3xl mx-auto backdrop-blur-md bg-white/5 border border-white/10 rounded-xl p-6 text-center"
          >
            <p className="text-white/60">
              💡 <strong className="text-white">Tip:</strong> You registered with multiple roles! You can access any dashboard 
              at any time from your profile menu.
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
