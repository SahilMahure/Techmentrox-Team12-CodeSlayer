import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { RadioGroup, RadioGroupItem } from "../components/ui/radio-group";
import { Checkbox } from "../components/ui/checkbox";
import { Progress } from "../components/ui/progress";
import { useNavigate } from "react-router";
import { Heart, ArrowLeft, ArrowRight, User, Building, Briefcase, GraduationCap } from "lucide-react";
import logo from "figma:asset/c0160807a5cb025e77d8935afa6685098e9c8896.png";
import { CanvasRevealEffect } from "../components/CanvasRevealEffect";

type UserType = "individual" | "college" | "business" | "ngo";
type Role = "donor" | "volunteer" | "ngo-role";

interface FormData {
  userType: UserType;
  name: string;
  organizationName: string;
  contactNumber: string;
  email: string;
  city: string;
  area: string;
  roles: Role[];
}

export default function Onboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<FormData>({
    userType: "individual",
    name: "",
    organizationName: "",
    contactNumber: "",
    email: "",
    city: "",
    area: "",
    roles: [],
  });

  const totalSteps = 3;
  const progress = (step / totalSteps) * 100;

  const handleRoleToggle = (role: Role) => {
    setFormData(prev => ({
      ...prev,
      roles: prev.roles.includes(role)
        ? prev.roles.filter(r => r !== role)
        : [...prev.roles, role]
    }));
  };

  const handleSubmit = () => {
    localStorage.setItem('userProfile', JSON.stringify(formData));
    navigate('/role-selection');
  };

  const canProceed = () => {
    if (step === 1) return formData.userType !== "";
    if (step === 2) {
      return formData.name && formData.email && formData.contactNumber && formData.city && formData.area;
    }
    if (step === 3) return formData.roles.length > 0;
    return false;
  };

  return (
    <div className="relative min-h-screen bg-black overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 z-0">
        <CanvasRevealEffect
          animationSpeed={3}
          containerClassName="bg-black"
          colors={[
            [255, 166, 0],
            [255, 200, 100],
          ]}
          dotSize={4}
        />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(0,0,0,0.3)_0%,_rgba(0,0,0,0.9)_100%)]" />
      </div>

      {/* Content */}
      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Floating Header */}
        <nav className="fixed top-6 left-1/2 transform -translate-x-1/2 z-50">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-6 px-6 py-3 backdrop-blur-md bg-white/5 border border-white/10 rounded-full"
          >
            <div className="flex items-center gap-2">
              <img src={logo} alt="Link4Good" className="size-8" />
              <span className="text-white font-semibold">Link4Good</span>
            </div>
            <div className="h-4 w-px bg-white/20"></div>
            <Button 
              variant="ghost" 
              onClick={() => navigate('/')}
              className="text-white hover:bg-white/10 rounded-full"
              size="sm"
            >
              <ArrowLeft className="size-4 mr-2" />
              Back
            </Button>
          </motion.div>
        </nav>

        {/* Progress Bar */}
        <div className="fixed top-24 left-0 right-0 z-40">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 backdrop-blur-md bg-white/5 border border-white/10 rounded-2xl"
            >
              <div className="space-y-2">
                <div className="flex justify-between text-sm text-white/60">
                  <span>Step {step} of {totalSteps}</span>
                  <span>{Math.round(progress)}% Complete</span>
                </div>
                <Progress value={progress} className="h-2 bg-white/10" />
              </div>
            </motion.div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 mt-32">
          <div className="w-full max-w-2xl">
            <AnimatePresence mode="wait">
              {/* Step 1: User Type */}
              {step === 1 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="backdrop-blur-md bg-white/5 border border-white/10 rounded-2xl p-8 sm:p-12"
                >
                  <div className="mb-8">
                    <h2 className="text-3xl text-white mb-3">Welcome! Let's get to know you</h2>
                    <p className="text-white/60">Tell us about yourself or your organization</p>
                  </div>

                  <div className="space-y-4">
                    <Label className="text-white">I am a/an:</Label>
                    <RadioGroup
                      value={formData.userType}
                      onValueChange={(value) => setFormData({ ...formData, userType: value as UserType })}
                      className="grid grid-cols-1 sm:grid-cols-2 gap-4"
                    >
                      {[
                        { value: "individual", icon: User, label: "Individual", desc: "Personal account" },
                        { value: "college", icon: GraduationCap, label: "College Club", desc: "Student organization" },
                        { value: "business", icon: Briefcase, label: "Business", desc: "Corporate account" },
                        { value: "ngo", icon: Building, label: "NGO", desc: "Non-profit organization" },
                      ].map((type) => (
                        <label
                          key={type.value}
                          className={`flex items-start gap-4 p-4 rounded-xl border-2 cursor-pointer transition-all backdrop-blur-sm ${
                            formData.userType === type.value
                              ? "border-amber-500 bg-amber-500/10"
                              : "border-white/10 hover:border-amber-500/50 bg-white/5"
                          }`}
                        >
                          <RadioGroupItem value={type.value} className="mt-1" />
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <type.icon className="size-5 text-white" />
                              <span className="font-medium text-white">{type.label}</span>
                            </div>
                            <p className="text-sm text-white/60">{type.desc}</p>
                          </div>
                        </label>
                      ))}
                    </RadioGroup>
                  </div>
                </motion.div>
              )}

              {/* Step 2: Details */}
              {step === 2 && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="backdrop-blur-md bg-white/5 border border-white/10 rounded-2xl p-8 sm:p-12"
                >
                  <div className="mb-8">
                    <h2 className="text-3xl text-white mb-3">Your Details</h2>
                    <p className="text-white/60">Help us coordinate better with accurate information</p>
                  </div>

                  <div className="space-y-6">
                    <div className="grid sm:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="name" className="text-white">
                          {formData.userType === "individual" ? "Full Name" : "Contact Person Name"}
                        </Label>
                        <Input
                          id="name"
                          placeholder="John Doe"
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                        />
                      </div>

                      {formData.userType !== "individual" && (
                        <div className="space-y-2">
                          <Label htmlFor="org" className="text-white">Organization Name</Label>
                          <Input
                            id="org"
                            placeholder="Organization name"
                            value={formData.organizationName}
                            onChange={(e) => setFormData({ ...formData, organizationName: e.target.value })}
                            className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                          />
                        </div>
                      )}
                    </div>

                    <div className="grid sm:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="email" className="text-white">Email Address</Label>
                        <Input
                          id="email"
                          type="email"
                          placeholder="john@example.com"
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="phone" className="text-white">Contact Number</Label>
                        <Input
                          id="phone"
                          type="tel"
                          placeholder="+1 234 567 8900"
                          value={formData.contactNumber}
                          onChange={(e) => setFormData({ ...formData, contactNumber: e.target.value })}
                          className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                        />
                      </div>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="city" className="text-white">City</Label>
                        <Input
                          id="city"
                          placeholder="New York"
                          value={formData.city}
                          onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                          className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="area" className="text-white">Area / Neighborhood</Label>
                        <Input
                          id="area"
                          placeholder="Manhattan"
                          value={formData.area}
                          onChange={(e) => setFormData({ ...formData, area: e.target.value })}
                          className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                        />
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Step 3: Role Selection */}
              {step === 3 && (
                <motion.div
                  key="step3"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="backdrop-blur-md bg-white/5 border border-white/10 rounded-2xl p-8 sm:p-12"
                >
                  <div className="mb-8">
                    <h2 className="text-3xl text-white mb-3">How would you like to contribute?</h2>
                    <p className="text-white/60">You can select multiple roles</p>
                  </div>

                  <div className="space-y-4">
                    {[
                      {
                        role: "donor" as Role,
                        title: "Donor",
                        description: "Donate clothes, food, or essential items to those in need",
                        borderColor: "border-amber-500",
                        bgColor: "bg-amber-500/10"
                      },
                      {
                        role: "volunteer" as Role,
                        title: "Volunteer",
                        description: "Help coordinate and deliver donations to NGOs",
                        borderColor: "border-blue-500",
                        bgColor: "bg-blue-500/10"
                      },
                      {
                        role: "ngo-role" as Role,
                        title: "NGO / Recipient",
                        description: "Receive and distribute donations to communities",
                        borderColor: "border-emerald-500",
                        bgColor: "bg-emerald-500/10"
                      },
                    ].map((item) => (
                      <label
                        key={item.role}
                        className={`flex items-start gap-4 p-6 rounded-xl border-2 cursor-pointer transition-all backdrop-blur-sm ${
                          formData.roles.includes(item.role)
                            ? `${item.borderColor} ${item.bgColor}`
                            : "border-white/10 hover:border-white/30 bg-white/5"
                        }`}
                      >
                        <Checkbox
                          checked={formData.roles.includes(item.role)}
                          onCheckedChange={() => handleRoleToggle(item.role)}
                          className="mt-1"
                        />
                        <div>
                          <h3 className="font-medium text-lg mb-1 text-white">{item.title}</h3>
                          <p className="text-white/60">{item.description}</p>
                        </div>
                      </label>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-8">
              <Button
                variant="outline"
                onClick={() => setStep(step - 1)}
                disabled={step === 1}
                className="bg-white/5 hover:bg-white/10 text-white border-white/20 rounded-full"
              >
                <ArrowLeft className="size-4 mr-2" />
                Previous
              </Button>

              {step < totalSteps ? (
                <Button
                  onClick={() => setStep(step + 1)}
                  disabled={!canProceed()}
                  className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white border-0 rounded-full disabled:opacity-50"
                >
                  Next
                  <ArrowRight className="size-4 ml-2" />
                </Button>
              ) : (
                <Button
                  onClick={handleSubmit}
                  disabled={!canProceed()}
                  className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white border-0 rounded-full disabled:opacity-50"
                >
                  Complete Setup
                  <ArrowRight className="size-4 ml-2" />
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
