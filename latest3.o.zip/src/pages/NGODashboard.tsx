import { useState } from "react";
import { DashboardLayout } from "../components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { OpenStreetMap } from "../components/OpenStreetMap";
import { mockDonations, mockVolunteers, mockRecognition } from "../lib/mockData";
import { Package, CheckCircle, Clock, MapPin, Calendar, Award, TrendingUp, User, Phone } from "lucide-react";
import { motion } from "motion/react";
import { toast } from "sonner@2.0.3";

interface IncomingDelivery {
  id: string;
  donorName: string;
  volunteerName: string;
  type: "clothes" | "food" | "essentials";
  quantity: string;
  scheduledDate: string;
  scheduledTime: string;
  status: "scheduled" | "in-transit" | "received" | "distributed";
  donorContact?: string;
  volunteerContact?: string;
}

export default function NGODashboard() {
  const [deliveries, setDeliveries] = useState<IncomingDelivery[]>([
    {
      id: "ND001",
      donorName: "John Smith",
      volunteerName: "Sarah Johnson",
      type: "clothes",
      quantity: "15 items",
      scheduledDate: "2026-02-07",
      scheduledTime: "2:00 PM",
      status: "in-transit",
      donorContact: "+1 234 567 8901",
      volunteerContact: "+1 234 567 8902"
    },
    {
      id: "ND002",
      donorName: "Maria Garcia",
      volunteerName: "Mike Chen",
      type: "food",
      quantity: "25 kg",
      scheduledDate: "2026-02-07",
      scheduledTime: "4:30 PM",
      status: "scheduled",
      donorContact: "+1 234 567 8903",
      volunteerContact: "+1 234 567 8904"
    },
    {
      id: "ND003",
      donorName: "Tech Corp Inc.",
      volunteerName: "Emily Rodriguez",
      type: "essentials",
      quantity: "50 units",
      scheduledDate: "2026-02-06",
      scheduledTime: "11:00 AM",
      status: "received",
      donorContact: "+1 234 567 8905",
      volunteerContact: "+1 234 567 8906"
    },
    {
      id: "ND004",
      donorName: "Anna Williams",
      volunteerName: "David Park",
      type: "clothes",
      quantity: "20 bags",
      scheduledDate: "2026-02-05",
      scheduledTime: "1:00 PM",
      status: "distributed",
      donorContact: "+1 234 567 8907",
      volunteerContact: "+1 234 567 8908"
    }
  ]);

  const [activeTab, setActiveTab] = useState<string>("in-transit");

  // Get user profile from localStorage
  const userProfile = JSON.parse(localStorage.getItem('userProfile') || '{}');
  const organizationName = userProfile.organizationName || userProfile.name || 'NGO';

  const handleMarkReceived = (deliveryId: string) => {
    setDeliveries(prev => prev.map(d => 
      d.id === deliveryId ? { ...d, status: "received" as const } : d
    ));
    toast.success("Delivery marked as received", {
      description: "Thank you for confirming!"
    });
  };

  const handleMarkDistributed = (deliveryId: string) => {
    setDeliveries(prev => prev.map(d => 
      d.id === deliveryId ? { ...d, status: "distributed" as const } : d
    ));
    toast.success("Marked as distributed! 🎉", {
      description: "Impact tracked successfully."
    });
  };

  const getStatusColor = (status: IncomingDelivery['status']) => {
    switch (status) {
      case "distributed": return "bg-emerald-100 text-emerald-800 border-emerald-200";
      case "received": return "bg-blue-100 text-blue-800 border-blue-200";
      case "in-transit": return "bg-amber-100 text-amber-800 border-amber-200";
      case "scheduled": return "bg-purple-100 text-purple-800 border-purple-200";
    }
  };

  const getStatusIcon = (status: IncomingDelivery['status']) => {
    switch (status) {
      case "distributed": return <CheckCircle className="size-4" />;
      case "received": return <Package className="size-4" />;
      case "in-transit": return <MapPin className="size-4" />;
      case "scheduled": return <Clock className="size-4" />;
    }
  };

  const getTypeEmoji = (type: IncomingDelivery['type']) => {
    switch (type) {
      case "clothes": return "👕";
      case "food": return "🍲";
      case "essentials": return "📦";
    }
  };

  const stats = {
    scheduled: deliveries.filter(d => d.status === "scheduled").length,
    inTransit: deliveries.filter(d => d.status === "in-transit").length,
    received: deliveries.filter(d => d.status === "received").length,
    distributed: deliveries.filter(d => d.status === "distributed").length,
    total: deliveries.length
  };

  // Map data for in-transit deliveries
  const mapLocations = deliveries
    .filter(d => d.status === "in-transit")
    .flatMap(d => [
      { lat: 40.7128, lng: -74.0060, label: "Donor Location", type: "pickup" as const },
      { lat: 40.7580, lng: -73.9855, label: d.volunteerName, type: "volunteer" as const },
      { lat: 40.7489, lng: -73.9680, label: "Your NGO", type: "ngo" as const }
    ]);

  return (
    <DashboardLayout role="ngo">
      <div className="space-y-8">
        {/* Welcome Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl p-8 text-white shadow-xl"
        >
          <h1 className="text-3xl mb-2">Welcome, {organizationName}! 💚</h1>
          <p className="text-emerald-50 text-lg">
            Together, we're transforming lives and building a better tomorrow.
          </p>
        </motion.div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[
            { label: "In Transit", value: stats.inTransit, icon: MapPin, color: "text-amber-600 bg-amber-100", tab: "in-transit" },
            { label: "Scheduled", value: stats.scheduled, icon: Calendar, color: "text-purple-600 bg-purple-100", tab: "scheduled" },
            { label: "Received", value: stats.received, icon: Package, color: "text-blue-600 bg-blue-100", tab: "received" },
            { label: "Distributed", value: stats.distributed + 142, icon: TrendingUp, color: "text-emerald-600 bg-emerald-100", tab: "distributed" }
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card 
                className="hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => {
                  setActiveTab(stat.tab);
                  // Scroll to delivery management section
                  setTimeout(() => {
                    document.getElementById('delivery-management')?.scrollIntoView({ behavior: 'smooth' });
                  }, 100);
                }}
              >
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">{stat.label}</p>
                      <p className="text-3xl font-semibold mt-1">{stat.value}</p>
                    </div>
                    <div className={`p-3 rounded-xl ${stat.color}`}>
                      <stat.icon className="size-6" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content - Left Side */}
          <div className="lg:col-span-2 space-y-6">
            {/* Delivery Management */}
            <Card id="delivery-management">
              <CardHeader>
                <CardTitle>Delivery Management</CardTitle>
                <CardDescription>Track and manage incoming donations</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="in-transit">
                      In Transit ({stats.inTransit})
                    </TabsTrigger>
                    <TabsTrigger value="scheduled">
                      Scheduled ({stats.scheduled})
                    </TabsTrigger>
                    <TabsTrigger value="received">
                      Received ({stats.received})
                    </TabsTrigger>
                    <TabsTrigger value="distributed">
                      Distributed ({stats.distributed})
                    </TabsTrigger>
                  </TabsList>

                  {/* In Transit */}
                  <TabsContent value="in-transit" className="space-y-3">
                    {deliveries
                      .filter(d => d.status === "in-transit")
                      .map((delivery, index) => (
                        <motion.div
                          key={delivery.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.05 }}
                        >
                          <Card className="hover:shadow-md transition-shadow border-2 border-amber-200 bg-amber-50/50">
                            <CardContent className="pt-6">
                              <div className="space-y-4">
                                <div className="flex items-start justify-between">
                                  <div className="flex gap-3 flex-1">
                                    <div className="text-3xl">{getTypeEmoji(delivery.type)}</div>
                                    <div className="flex-1">
                                      <div className="flex items-center gap-2 mb-2">
                                        <h4 className="font-semibold">From {delivery.donorName}</h4>
                                        <Badge className={getStatusColor(delivery.status)}>
                                          {getStatusIcon(delivery.status)}
                                          <span className="ml-1 capitalize">{delivery.status}</span>
                                        </Badge>
                                      </div>
                                      <div className="space-y-1 text-sm text-muted-foreground">
                                        <p>📦 {delivery.quantity} of {delivery.type}</p>
                                        <p>👤 Volunteer: {delivery.volunteerName}</p>
                                        <p>📅 Expected: {new Date(delivery.scheduledDate).toLocaleDateString()} at {delivery.scheduledTime}</p>
                                      </div>
                                    </div>
                                  </div>
                                </div>

                                <div className="flex gap-2">
                                  <Button size="sm" variant="outline" className="flex-1">
                                    <MapPin className="size-4 mr-2" />
                                    Track Live
                                  </Button>
                                  <Button 
                                    size="sm" 
                                    className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                                    onClick={() => handleMarkReceived(delivery.id)}
                                  >
                                    <CheckCircle className="size-4 mr-2" />
                                    Mark Received
                                  </Button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                    {deliveries.filter(d => d.status === "in-transit").length === 0 && (
                      <div className="text-center py-12 text-muted-foreground">
                        <MapPin className="size-12 mx-auto mb-4 opacity-30" />
                        <p>No deliveries in transit</p>
                      </div>
                    )}
                  </TabsContent>

                  {/* Scheduled */}
                  <TabsContent value="scheduled" className="space-y-3">
                    {deliveries
                      .filter(d => d.status === "scheduled")
                      .map((delivery, index) => (
                        <motion.div
                          key={delivery.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.05 }}
                        >
                          <Card className="hover:shadow-md transition-shadow">
                            <CardContent className="pt-6">
                              <div className="flex items-start gap-3">
                                <div className="text-3xl">{getTypeEmoji(delivery.type)}</div>
                                <div className="flex-1">
                                  <div className="flex items-center gap-2 mb-2">
                                    <h4 className="font-semibold">{delivery.donorName}</h4>
                                    <Badge className={getStatusColor(delivery.status)}>
                                      {getStatusIcon(delivery.status)}
                                      <span className="ml-1 capitalize">{delivery.status}</span>
                                    </Badge>
                                  </div>
                                  <div className="space-y-1 text-sm text-muted-foreground">
                                    <p>📦 {delivery.quantity} of {delivery.type}</p>
                                    <p>👤 Volunteer: {delivery.volunteerName}</p>
                                    <p>📅 Scheduled: {new Date(delivery.scheduledDate).toLocaleDateString()} at {delivery.scheduledTime}</p>
                                  </div>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                    {deliveries.filter(d => d.status === "scheduled").length === 0 && (
                      <div className="text-center py-12 text-muted-foreground">
                        <Calendar className="size-12 mx-auto mb-4 opacity-30" />
                        <p>No scheduled deliveries</p>
                      </div>
                    )}
                  </TabsContent>

                  {/* Received */}
                  <TabsContent value="received" className="space-y-3">
                    {deliveries
                      .filter(d => d.status === "received")
                      .map((delivery, index) => (
                        <motion.div
                          key={delivery.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.05 }}
                        >
                          <Card className="hover:shadow-md transition-shadow border-2 border-blue-200 bg-blue-50/50">
                            <CardContent className="pt-6">
                              <div className="space-y-4">
                                <div className="flex items-start gap-3">
                                  <div className="text-3xl">{getTypeEmoji(delivery.type)}</div>
                                  <div className="flex-1">
                                    <div className="flex items-center gap-2 mb-2">
                                      <h4 className="font-semibold">{delivery.donorName}</h4>
                                      <Badge className={getStatusColor(delivery.status)}>
                                        {getStatusIcon(delivery.status)}
                                        <span className="ml-1">Received</span>
                                      </Badge>
                                    </div>
                                    <div className="space-y-1 text-sm text-muted-foreground">
                                      <p>📦 {delivery.quantity} of {delivery.type}</p>
                                      <p>📅 Received: {new Date(delivery.scheduledDate).toLocaleDateString()}</p>
                                    </div>
                                  </div>
                                </div>

                                <Button 
                                  size="sm" 
                                  className="w-full bg-emerald-600 hover:bg-emerald-700"
                                  onClick={() => handleMarkDistributed(delivery.id)}
                                >
                                  <CheckCircle className="size-4 mr-2" />
                                  Mark as Distributed
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                    {deliveries.filter(d => d.status === "received").length === 0 && (
                      <div className="text-center py-12 text-muted-foreground">
                        <Package className="size-12 mx-auto mb-4 opacity-30" />
                        <p>No received items pending distribution</p>
                      </div>
                    )}
                  </TabsContent>

                  {/* Distributed */}
                  <TabsContent value="distributed" className="space-y-3">
                    {deliveries
                      .filter(d => d.status === "distributed")
                      .map((delivery, index) => (
                        <motion.div
                          key={delivery.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.05 }}
                        >
                          <Card className="hover:shadow-md transition-shadow">
                            <CardContent className="pt-6">
                              <div className="flex items-start gap-3">
                                <CheckCircle className="size-5 text-emerald-600 mt-1" />
                                <div className="flex-1">
                                  <h4 className="font-medium mb-1">{delivery.donorName} → Community</h4>
                                  <p className="text-sm text-muted-foreground">
                                    {delivery.quantity} distributed • {new Date(delivery.scheduledDate).toLocaleDateString()}
                                  </p>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                    <div className="text-center py-8 text-muted-foreground border-t">
                      <p className="text-sm">Showing recent distributions</p>
                      <p className="text-xs mt-1">Total lifetime impact: 142 distributions</p>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            {/* Map View */}
            {mapLocations.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Incoming Deliveries Tracking</CardTitle>
                  <CardDescription>Real-time location of deliveries heading your way</CardDescription>
                </CardHeader>
                <CardContent>
                  <OpenStreetMap locations={mapLocations} />
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">
            {/* Active Volunteers */}
            <Card>
              <CardHeader>
                <CardTitle>Active Volunteers</CardTitle>
                <CardDescription>Volunteers helping you today</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {mockVolunteers.slice(0, 3).map((volunteer) => (
                  <Card key={volunteer.id} className="border border-border hover:border-blue-300 transition-colors">
                    <CardContent className="pt-4">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="size-10 rounded-full bg-blue-100 flex items-center justify-center">
                          <User className="size-5 text-blue-600" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-sm">{volunteer.name}</h4>
                          <p className="text-xs text-muted-foreground">{volunteer.completedDeliveries} deliveries</p>
                        </div>
                      </div>
                      <Button size="sm" variant="outline" className="w-full">
                        <Phone className="size-3 mr-2" />
                        Contact
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </CardContent>
            </Card>

            {/* Impact Summary */}
            <Card className="bg-gradient-to-br from-emerald-50 to-teal-50 border-2 border-emerald-200">
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="text-5xl mb-3">💚</div>
                  <h3 className="font-semibold mb-2">Monthly Impact</h3>
                  <div className="text-3xl font-bold text-emerald-700 mb-2">1,200+</div>
                  <p className="text-sm text-muted-foreground mb-4">Lives touched this month</p>
                  <div className="space-y-2 text-left">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Families served</span>
                      <span className="font-medium">320</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Total donations</span>
                      <span className="font-medium">142</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Active volunteers</span>
                      <span className="font-medium">28</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Appreciation Section */}
        <div id="appreciation-section">
          <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-2 border-purple-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="size-6 text-purple-600" />
                This Month's Champions
              </CardTitle>
              <CardDescription>Celebrating our community heroes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                {/* Donor of the Month */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                >
                  <Card className="bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200">
                    <CardContent className="pt-6 text-center">
                      <div className="text-4xl mb-3">🏆</div>
                      <h3 className="font-semibold mb-1">Donor of the Month</h3>
                      <p className="text-lg font-medium text-amber-700 mb-2">{mockRecognition.donorOfMonth.name}</p>
                      <Badge className="bg-amber-100 text-amber-800 border-amber-200 mb-3">
                        {mockRecognition.donorOfMonth.badge}
                      </Badge>
                      <p className="text-sm text-muted-foreground">{mockRecognition.donorOfMonth.contributions}</p>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Volunteer of the Month */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200">
                    <CardContent className="pt-6 text-center">
                      <div className="text-4xl mb-3">⭐</div>
                      <h3 className="font-semibold mb-1">Volunteer of the Month</h3>
                      <p className="text-lg font-medium text-blue-700 mb-2">{mockRecognition.volunteerOfMonth.name}</p>
                      <Badge className="bg-blue-100 text-blue-800 border-blue-200 mb-3">
                        {mockRecognition.volunteerOfMonth.badge}
                      </Badge>
                      <p className="text-sm text-muted-foreground">{mockRecognition.volunteerOfMonth.deliveries} deliveries completed</p>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* NGO of the Month */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  <Card className="bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-200">
                    <CardContent className="pt-6 text-center">
                      <div className="text-4xl mb-3">💚</div>
                      <h3 className="font-semibold mb-1">NGO of the Month</h3>
                      <p className="text-lg font-medium text-emerald-700 mb-2">{mockRecognition.ngoOfMonth.name}</p>
                      <Badge className="bg-emerald-100 text-emerald-800 border-emerald-200 mb-3">
                        {mockRecognition.ngoOfMonth.badge}
                      </Badge>
                      <p className="text-sm text-muted-foreground">{mockRecognition.ngoOfMonth.impact}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}