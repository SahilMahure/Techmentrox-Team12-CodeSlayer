import { MapPin, Navigation } from "lucide-react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";

interface MapLocation {
  lat: number;
  lng: number;
  label: string;
  type: "pickup" | "delivery" | "volunteer" | "ngo";
}

interface SimpleMapProps {
  locations: MapLocation[];
  height?: string;
}

export function SimpleMap({ locations, height = "h-96" }: SimpleMapProps) {
  const getMarkerColor = (type: MapLocation['type']) => {
    switch (type) {
      case "pickup": return "bg-amber-500";
      case "delivery": return "bg-emerald-500";
      case "volunteer": return "bg-blue-500";
      case "ngo": return "bg-purple-500";
      default: return "bg-gray-500";
    }
  };

  const getMarkerIcon = (type: MapLocation['type']) => {
    switch (type) {
      case "pickup": return "📦";
      case "delivery": return "🏢";
      case "volunteer": return "👤";
      case "ngo": return "🏛️";
      default: return "📍";
    }
  };

  return (
    <Card className={`${height} relative overflow-hidden bg-gradient-to-br from-blue-50 to-green-50`}>
      {/* Map Background Grid */}
      <div className="absolute inset-0 opacity-20">
        <div className="grid grid-cols-10 grid-rows-10 h-full w-full">
          {Array.from({ length: 100 }).map((_, i) => (
            <div key={i} className="border border-gray-300"></div>
          ))}
        </div>
      </div>

      {/* Map Content */}
      <div className="relative h-full p-6">
        {/* Title */}
        <div className="absolute top-4 left-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg shadow-md p-3 z-10">
          <div className="flex items-center gap-2">
            <Navigation className="size-5 text-blue-600" />
            <span className="font-medium">Live Tracking Map</span>
          </div>
        </div>

        {/* Location Markers */}
        <div className="relative h-full pt-16">
          {locations.map((location, index) => {
            // Position markers relatively based on lat/lng (simplified)
            const top = ((90 - location.lat) / 90) * 60 + 10; // rough conversion
            const left = ((location.lng + 180) / 360) * 80 + 10;
            
            return (
              <div
                key={index}
                className="absolute group cursor-pointer"
                style={{ 
                  top: `${top}%`, 
                  left: `${left}%`,
                  transform: 'translate(-50%, -50%)'
                }}
              >
                {/* Marker */}
                <div className={`size-10 ${getMarkerColor(location.type)} rounded-full shadow-lg flex items-center justify-center text-xl animate-bounce`}>
                  {getMarkerIcon(location.type)}
                </div>
                
                {/* Tooltip */}
                <div className="absolute bottom-full mb-2 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                  <div className="bg-white px-3 py-2 rounded-lg shadow-lg whitespace-nowrap border border-border">
                    <div className="text-sm font-medium">{location.label}</div>
                    <Badge variant="secondary" className="text-xs mt-1">
                      {location.type}
                    </Badge>
                  </div>
                  <div className="absolute top-full left-1/2 transform -translate-x-1/2 -mt-1">
                    <div className="border-8 border-transparent border-t-white"></div>
                  </div>
                </div>

                {/* Pulse effect */}
                <div className={`absolute inset-0 ${getMarkerColor(location.type)} rounded-full animate-ping opacity-30`}></div>
              </div>
            );
          })}

          {/* Route Lines (simplified) */}
          {locations.length > 1 && (
            <svg className="absolute inset-0 pointer-events-none" style={{ width: '100%', height: '100%' }}>
              {locations.slice(0, -1).map((location, index) => {
                const nextLocation = locations[index + 1];
                const x1 = ((location.lng + 180) / 360) * 80 + 10;
                const y1 = ((90 - location.lat) / 90) * 60 + 10;
                const x2 = ((nextLocation.lng + 180) / 360) * 80 + 10;
                const y2 = ((90 - nextLocation.lat) / 90) * 60 + 10;
                
                return (
                  <line
                    key={index}
                    x1={`${x1}%`}
                    y1={`${y1}%`}
                    x2={`${x2}%`}
                    y2={`${y2}%`}
                    stroke="#3b82f6"
                    strokeWidth="3"
                    strokeDasharray="5,5"
                    opacity="0.5"
                  />
                );
              })}
            </svg>
          )}
        </div>

        {/* Legend */}
        <div className="absolute bottom-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg shadow-md p-3">
          <div className="space-y-2 text-xs">
            <div className="flex items-center gap-2">
              <div className="size-3 bg-amber-500 rounded-full"></div>
              <span>Pickup Point</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="size-3 bg-emerald-500 rounded-full"></div>
              <span>Delivery Point</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="size-3 bg-blue-500 rounded-full"></div>
              <span>Volunteer</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="size-3 bg-purple-500 rounded-full"></div>
              <span>NGO</span>
            </div>
          </div>
        </div>

        {/* Scale indicator */}
        <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg shadow-md px-3 py-2 text-xs flex items-center gap-2">
          <MapPin className="size-3" />
          <span>Real-time tracking</span>
        </div>
      </div>
    </Card>
  );
}
