import { useEffect, useRef } from "react";
import { Navigation } from "lucide-react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";

interface MapLocation {
  lat: number;
  lng: number;
  label: string;
  type: "pickup" | "delivery" | "volunteer" | "ngo";
}

interface OpenStreetMapProps {
  locations: MapLocation[];
  height?: string;
  defaultCenter?: [number, number];
  defaultZoom?: number;
}

export function OpenStreetMap({ 
  locations, 
  height = "h-96",
  defaultCenter = [40.7128, -74.0060],
  defaultZoom = 12
}: OpenStreetMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const markersRef = useRef<any[]>([]);

  const getMarkerColor = (type: MapLocation['type']) => {
    switch (type) {
      case "pickup": return "#f59e0b"; // amber-500
      case "delivery": return "#10b981"; // emerald-500
      case "volunteer": return "#3b82f6"; // blue-500
      case "ngo": return "#a855f7"; // purple-500
      default: return "#6b7280"; // gray-500
    }
  };

  const getMarkerIcon = (type: MapLocation['type']) => {
    switch (type) {
      case "pickup": return "📦";
      case "delivery": return "🏢";
      case "volunteer": return "👤";
      case "ngo": return "🏛️";
      default: return "📍";
    }
  };

  useEffect(() => {
    // Load Leaflet CSS and JS dynamically
    const loadLeaflet = async () => {
      // Load CSS
      if (!document.getElementById('leaflet-css')) {
        const link = document.createElement('link');
        link.id = 'leaflet-css';
        link.rel = 'stylesheet';
        link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
        link.integrity = 'sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=';
        link.crossOrigin = '';
        document.head.appendChild(link);
      }

      // Load JS
      if (!(window as any).L) {
        await new Promise((resolve, reject) => {
          const script = document.createElement('script');
          script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
          script.integrity = 'sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=';
          script.crossOrigin = '';
          script.onload = resolve;
          script.onerror = reject;
          document.head.appendChild(script);
        });
      }

      return (window as any).L;
    };

    const initMap = async () => {
      if (!mapRef.current) return;

      const L = await loadLeaflet();

      // Clear existing map if any
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
      }

      // Calculate center from locations or use default
      const center = locations.length > 0 
        ? [locations[0].lat, locations[0].lng] as [number, number]
        : defaultCenter;

      // Initialize map
      const map = L.map(mapRef.current).setView(center, defaultZoom);

      // Add OpenStreetMap tiles
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19,
      }).addTo(map);

      mapInstanceRef.current = map;

      // Clear existing markers
      markersRef.current.forEach(marker => marker.remove());
      markersRef.current = [];

      // Add markers for each location
      locations.forEach((location, index) => {
        const color = getMarkerColor(location.type);
        const emoji = getMarkerIcon(location.type);

        // Create custom icon with emoji
        const customIcon = L.divIcon({
          className: 'custom-marker',
          html: `
            <div style="position: relative;">
              <div style="
                width: 40px;
                height: 40px;
                background-color: ${color};
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 20px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                border: 3px solid white;
              ">
                ${emoji}
              </div>
              <div style="
                position: absolute;
                top: 100%;
                left: 50%;
                transform: translateX(-50%);
                width: 0;
                height: 0;
                border-left: 8px solid transparent;
                border-right: 8px solid transparent;
                border-top: 12px solid ${color};
              "></div>
            </div>
          `,
          iconSize: [40, 52],
          iconAnchor: [20, 52],
          popupAnchor: [0, -52]
        });

        const marker = L.marker([location.lat, location.lng], { icon: customIcon })
          .addTo(map)
          .bindPopup(`
            <div style="padding: 8px;">
              <strong style="font-size: 14px;">${location.label}</strong><br/>
              <span style="
                display: inline-block;
                background-color: ${color}20;
                color: ${color};
                padding: 2px 8px;
                border-radius: 12px;
                font-size: 12px;
                margin-top: 4px;
                font-weight: 500;
              ">${location.type}</span>
            </div>
          `);

        markersRef.current.push(marker);
      });

      // Draw route lines if there are multiple locations
      if (locations.length > 1) {
        const routeCoordinates = locations.map(loc => [loc.lat, loc.lng] as [number, number]);
        
        L.polyline(routeCoordinates, {
          color: '#3b82f6',
          weight: 3,
          opacity: 0.7,
          dashArray: '10, 10'
        }).addTo(map);

        // Fit map to show all markers
        const bounds = L.latLngBounds(routeCoordinates);
        map.fitBounds(bounds, { padding: [50, 50] });
      }

      // Invalidate size after a short delay to ensure proper rendering
      setTimeout(() => {
        map.invalidateSize();
      }, 100);
    };

    initMap();

    // Cleanup
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, [locations, defaultCenter, defaultZoom]);

  return (
    <Card className={`${height} relative overflow-hidden`}>
      {/* Map Container */}
      <div ref={mapRef} className="w-full h-full z-0" />

      {/* Controls Overlay */}
      <div className="absolute top-4 left-4 z-10 pointer-events-none">
        <div className="bg-white/95 backdrop-blur-sm rounded-lg shadow-lg p-3 pointer-events-auto">
          <div className="flex items-center gap-2">
            <Navigation className="size-5 text-blue-600" />
            <span className="font-medium text-gray-900">Live Tracking</span>
            <Badge variant="secondary" className="ml-2">
              {locations.length} {locations.length === 1 ? 'location' : 'locations'}
            </Badge>
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="absolute bottom-4 right-4 bg-white/95 backdrop-blur-sm rounded-lg shadow-lg p-3 z-10">
        <div className="space-y-2 text-xs">
          <div className="flex items-center gap-2">
            <div className="size-3 bg-amber-500 rounded-full"></div>
            <span className="text-gray-700">Pickup Point</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="size-3 bg-emerald-500 rounded-full"></div>
            <span className="text-gray-700">Delivery Point</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="size-3 bg-blue-500 rounded-full"></div>
            <span className="text-gray-700">Volunteer</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="size-3 bg-purple-500 rounded-full"></div>
            <span className="text-gray-700">NGO</span>
          </div>
        </div>
      </div>

      {/* Real-time indicator */}
      <div className="absolute bottom-4 left-4 bg-white/95 backdrop-blur-sm rounded-lg shadow-lg px-3 py-2 text-xs flex items-center gap-2 z-10">
        <div className="relative flex items-center">
          <div className="size-2 bg-green-500 rounded-full animate-pulse"></div>
          <div className="size-2 bg-green-500 rounded-full absolute animate-ping"></div>
        </div>
        <span className="font-medium text-gray-700">Live</span>
      </div>
    </Card>
  );
}