import { Home, Heart, Users, Building2, Award, LogOut } from "lucide-react";
import { useNavigate, useLocation } from "react-router";
import { Button } from "../components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "../components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "../components/ui/avatar";
import logo from "figma:asset/c0160807a5cb025e77d8935afa6685098e9c8896.png";
import { CanvasRevealEffect } from "../components/CanvasRevealEffect";

interface DashboardLayoutProps {
  children: React.ReactNode;
  role: "donor" | "volunteer" | "ngo";
}

export function DashboardLayout({ children, role }: DashboardLayoutProps) {
  const navigate = useNavigate();
  const location = useLocation();

  const roleConfig = {
    donor: {
      title: "Donor Dashboard",
      icon: Heart,
      gradient: "from-amber-500 to-orange-600",
      bgColor: "bg-amber-600",
      canvasColors: [[255, 166, 0], [255, 200, 100]] as [number, number, number][]
    },
    volunteer: {
      title: "Volunteer Dashboard",
      icon: Users,
      gradient: "from-blue-500 to-cyan-600",
      bgColor: "bg-blue-600",
      canvasColors: [[59, 130, 246], [6, 182, 212]] as [number, number, number][]
    },
    ngo: {
      title: "NGO Dashboard",
      icon: Building2,
      gradient: "from-emerald-500 to-teal-600",
      bgColor: "bg-emerald-600",
      canvasColors: [[16, 185, 129], [20, 184, 166]] as [number, number, number][]
    }
  };

  const config = roleConfig[role];
  const RoleIcon = config.icon;

  const userProfile = JSON.parse(localStorage.getItem('userProfile') || '{}');
  const initials = userProfile.name
    ? userProfile.name.split(' ').map((n: string) => n[0]).join('').toUpperCase()
    : 'U';

  return (
    <div className="relative min-h-screen bg-black overflow-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 z-0">
        <CanvasRevealEffect
          animationSpeed={3}
          containerClassName="bg-black"
          colors={config.canvasColors}
          dotSize={3}
        />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(0,0,0,0.4)_0%,_rgba(0,0,0,0.95)_100%)]" />
      </div>

      {/* Content */}
      <div className="relative z-10 min-h-screen">
        {/* Floating Top Navigation */}
        <nav className="fixed top-6 left-1/2 transform -translate-x-1/2 z-50 w-[calc(100%-2rem)] max-w-7xl">
          <div className="flex justify-between items-center px-6 py-3 backdrop-blur-md bg-white/5 border border-white/10 rounded-full">
            {/* Logo and Title */}
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <img src={logo} alt="Link4Good" className="size-8" />
                <span className="text-white font-semibold">Link4Good</span>
              </div>
              <div className="hidden sm:flex items-center gap-2 pl-4 border-l border-white/30">
                <RoleIcon className="size-4 text-white" />
                <span className="text-sm font-medium text-white">{config.title}</span>
              </div>
            </div>

            {/* Right Side Actions */}
            <div className="flex items-center gap-3">
              {/* Role Switcher */}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/role-selection')}
                className="hidden md:flex text-white hover:bg-white/10 rounded-full"
              >
                <Home className="size-4 mr-2" />
                Switch Role
              </Button>

              {/* User Menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-9 w-9 rounded-full hover:bg-white/10">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className={`bg-gradient-to-br ${config.gradient} text-white text-sm`}>
                        {initials}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56 bg-black/90 backdrop-blur-md border-white/10 text-white">
                  <DropdownMenuLabel>
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium text-white">{userProfile.name || 'User'}</p>
                      <p className="text-xs text-white/60">{userProfile.email}</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator className="bg-white/10" />
                  <DropdownMenuItem onClick={() => navigate('/role-selection')} className="text-white hover:bg-white/10">
                    <Home className="mr-2 size-4" />
                    <span>Switch Role</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => {
                    const scrollToAppreciation = () => {
                      const element = document.getElementById('appreciation-section');
                      if (element) {
                        element.scrollIntoView({ behavior: 'smooth' });
                      }
                    };
                    if (location.pathname === '/donor' || location.pathname === '/volunteer' || location.pathname === '/ngo') {
                      scrollToAppreciation();
                    }
                  }} className="text-white hover:bg-white/10">
                    <Award className="mr-2 size-4" />
                    <span>Recognition</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator className="bg-white/10" />
                  <DropdownMenuItem onClick={() => navigate('/')} className="text-white hover:bg-white/10">
                    <LogOut className="mr-2 size-4" />
                    <span>Log Out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main className="pt-24 px-4 sm:px-6 lg:px-8 pb-8">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
