
  # Donation Coordination Platform UI

  This is a code bundle for Donation Coordination Platform UI. The original project is available at https://www.figma.com/design/ejdJyJ8O2fd6mwS9jEKL8J/Donation-Coordination-Platform-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  